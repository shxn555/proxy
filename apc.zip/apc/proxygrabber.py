import requests

url = " https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt"

r = requests.get(url)

f = open("proxy.txt", "a")
proxx = r.text + "\n"
f.writelines(proxx)