import os
import sys
import platform
import colorama
from colorama import Fore
colorama.init()
print("starting")
os.system("python proxygrabber.py")
print(Fore.BLUE + "done with scraping the proxeis")
os.system("python checker.py")
print(Fore.BLUE + "done :)")
