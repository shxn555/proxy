#coded by 0xAt0m1c
import urllib.request
import socket
import colorama
from colorama import Fore
colorama.init()
import threading
file_name = "proxy.txt"
#ipp = json.loads(r)
#print(ipp["data"][0]["ipPort"])

socket.setdefaulttimeout(180)
asdf = open(file_name, "r")
data = asdf.read()
proxyList = data.split("\n")
asdf.close()

def is_bad_proxy(pip):    
    try:        
        proxy_handler = urllib.request.ProxyHandler({'http': pip})        
        opener = urllib.request.build_opener(proxy_handler)
        opener.addheaders = [('User-agent', 'Mozilla/5.0')]
        urllib.request.install_opener(opener)        
        sock=urllib.request.urlopen('http://www.google.com')  # change the url address here
        #sock=urllib.urlopen(req)
    except urllib.error.HTTPError as e:
        return e.code
    except Exception as detail:
        return 1
    return 0

def check(item):
    if is_bad_proxy(item):
        pass
    else:
        print (Fore.WHITE + item, Fore.GREEN + " is working")
        f = open("cproxy.txt", "a")
        proxx = item + "\n"
        f.writelines(proxx)


threads = []
for i in range(len(proxyList)):
    t = threading.Thread(target=check, args=[proxyList[i]])
    t.daemon = True
    threads.append(t)
for i in range(len(proxyList)):
    threads[i].start()
for i in range(len(proxyList)):
    threads[i].join()
asdf.close()